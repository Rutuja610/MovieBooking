module.exports = {
  DB_URL: "mongodb://localhost:27017/moviesdb",
  secretKey: "my_movie_management",
};
